import tkinter as tk
from tkinter import messagebox
import subprocess

# Function to verify username and password
def verify_login():
    username = username_entry.get()
    password = password_entry.get()
    if username == "admin" and password == "password":  # Example credentials
        open_menu()
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

# Function to open the menu after successful login
def open_menu():
    login_window.destroy()  # Close the login window

    # Create a new menu window
    menu_window = tk.Tk()
    menu_window.title("Drone Management System")

    # Welcome label
    tk.Label(menu_window, text="Welcome to Drone Management System", font=("Arial", 14)).pack(pady=20)

    # Button to open gui.py
    tk.Button(menu_window, text="Bellman ford algorithm", font=("Arial", 12), command=lambda: run_script("gui.py"), width=20).pack(pady=10)

    # Button to open drone_management_gui.py
    tk.Button(menu_window, text="Dijkstra algorithm", font=("Arial", 12), command=lambda: run_script("drone_management_gui.py"), width=20).pack(pady=10)

    # Button to open star.py
    tk.Button(menu_window, text="A* algorithm", font=("Arial", 12), command=lambda: run_script("star.py"), width=20).pack(pady=10)

    menu_window.mainloop()

# Function to run a script
def run_script(script_name):
    try:
        subprocess.Popen(["python", script_name])  # Launch the script
    except Exception as e:
        messagebox.showerror("Error", f"Failed to run {script_name}.\nError: {str(e)}")

# Create the login window
login_window = tk.Tk()
login_window.title("Login")

# Login form
tk.Label(login_window, text="Username:", font=("Arial", 12)).grid(row=0, column=0, pady=10, padx=10)
username_entry = tk.Entry(login_window, font=("Arial", 12))
username_entry.grid(row=0, column=1, pady=10)

tk.Label(login_window, text="Password:", font=("Arial", 12)).grid(row=1, column=0, pady=10, padx=10)
password_entry = tk.Entry(login_window, font=("Arial", 12), show="*")
password_entry.grid(row=1, column=1, pady=10)

tk.Button(login_window, text="Login", font=("Arial", 12), command=verify_login).grid(row=2, column=0, columnspan=2, pady=20)

login_window.mainloop()
