import time
import heapq
import tkinter as tk
from tkinter import scrolledtext
import matplotlib.pyplot as plt
import networkx as nx


class Node:
    def __init__(self, id):
        self.id = id
        self.edges = []
        self.drones = [Drone(id, i + 1) for i in range(3)]  # Each node has 3 drones

    def add_edge(self, destination, weight):
        self.edges.append(Edge(self, destination, weight))


class Edge:
    def __init__(self, source, destination, weight):
        self.source = source
        self.destination = destination
        self.weight = weight


class Graph:
    def __init__(self):
        self.nodes = {}
        self.graph_nx = nx.Graph()
        self.unavailable_paths = set()  # Set to store unavailable paths

    def add_node(self, id):
        self.nodes[id] = Node(id)
        self.graph_nx.add_node(id)

    def add_edge(self, source_id, destination_id, weight):
        if source_id in self.nodes and destination_id in self.nodes:
            self.nodes[source_id].add_edge(self.nodes[destination_id], weight)
            self.nodes[destination_id].add_edge(self.nodes[source_id], weight)
            self.graph_nx.add_edge(source_id, destination_id, weight=weight)

    def add_unavailable_path(self, source_id, destination_id):
        self.unavailable_paths.add((source_id, destination_id))
        self.unavailable_paths.add((destination_id, source_id))

    def bellman_ford(self, start_id, end_id):
        distances = {node_id: float('inf') for node_id in self.nodes}
        previous_nodes = {node_id: None for node_id in self.nodes}
        distances[start_id] = 0

        for _ in range(len(self.nodes) - 1):
            for node in self.nodes.values():
                for edge in node.edges:
                    if (node.id, edge.destination.id) in self.unavailable_paths:
                        continue  # Skip unavailable paths
                    if distances[node.id] + edge.weight < distances[edge.destination.id]:
                        distances[edge.destination.id] = distances[node.id] + edge.weight
                        previous_nodes[edge.destination.id] = node.id

        path = self.reconstruct_path(previous_nodes, start_id, end_id)
        if not path or path[0] != start_id or path[-1] != end_id:
            return float('inf'), []  # Path not found due to unavailable paths

        return distances[end_id], path

    def reconstruct_path(self, previous_nodes, start_id, end_id):
        path = []
        current_node_id = end_id
        while current_node_id is not None:
            path.insert(0, current_node_id)
            current_node_id = previous_nodes[current_node_id]
        return path

    def display_graph(self, output_area):
        plt.figure(figsize=(8, 6))
        pos = nx.spring_layout(self.graph_nx)
        nx.draw(self.graph_nx, pos, with_labels=True, node_color="lightblue", edge_color="gray", font_weight="bold")
        labels = nx.get_edge_attributes(self.graph_nx, 'weight')
        nx.draw_networkx_edge_labels(self.graph_nx, pos, edge_labels=labels)
        plt.title("Graph Visualization")
        plt.show()
        output_area.insert("end", "Graph displayed successfully.\n")
        output_area.see("end")


class Drone:
    def __init__(self, node_id, drone_number):
        self.id = f"Drone{node_id}{drone_number}"
        self.available = True
        self.current_height = 60  # Default height
        self.speed = 10
        self.path = []
        self.arrival_time = None

    def assign_mission(self, source, destination, graph, output_area):
        self.available = False
        distance, self.path = graph.bellman_ford(source.id, destination.id)
        if distance == float('inf'):
            output_area.insert(
                "end", f"{self.id} cannot complete the mission. No path available from {source.id} to {destination.id}.\n"
            )
            output_area.see("end")
            self.available = True
            return

        CentralHub.authorize_flight(self, source, destination, graph, output_area, distance)

    def fly(self, source, destination, distance, output_area, collision_detected):
        start_time = time.time()
        time_required = distance / self.speed  # Time in hours
        self.arrival_time = start_time + (time_required * 3600)  # Convert time to seconds
        output_area.insert(
            "end",
            f"{self.id} started flying from Node {source.id} to Node {destination.id} at height {self.current_height} meters\n"
            f"Shortest Path: {' -> '.join(map(str, self.path))}\n"
            f"Estimated arrival time: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.arrival_time))}\n"
            "-------------------------------------------------------\n"
        )
        output_area.see("end")


class CentralHub:
    active_flights = []

    @staticmethod
    def assign_drone(order, graph, output_area):
        source_node = graph.nodes[order.source.id]

        # Assign a local drone if available
        for drone in source_node.drones:
            if drone.available:
                return drone

        # Find the nearest node with an available drone
        distances = {}
        for node_id in graph.nodes:
            distances[node_id], _ = graph.bellman_ford(order.source.id, node_id)

        nearest_node = None
        nearest_distance = float('inf')
        for node_id, distance in distances.items():
            if node_id == order.source.id:
                continue
            node = graph.nodes[node_id]
            for drone in node.drones:
                if drone.available and distance < nearest_distance:
                    nearest_node = node
                    nearest_distance = distance

        if nearest_node:
            for drone in nearest_node.drones:
                if drone.available:
                    output_area.insert(
                        "end",
                        f"Borrowing drone {drone.id} from nearest node {nearest_node.id} for order at Node {order.source.id}\n"
                    )
                    output_area.see("end")
                    return drone

        output_area.insert("end", "No drones available in the entire network.\n")
        return None

    @staticmethod
    def authorize_flight(drone, source, destination, graph, output_area, distance):
        collision_detected = CentralHub.resolve_conflicts(drone, graph, output_area)
        drone.fly(source, destination, distance, output_area, collision_detected)

    @staticmethod
    def resolve_conflicts(drone, graph, output_area):
        collision_detected = False
        for active_drone, active_path, active_height in CentralHub.active_flights:
            for i in range(len(active_path) - 1):
                for j in range(len(drone.path) - 1):
                    if (active_path[i] == drone.path[j + 1] and active_path[i + 1] == drone.path[j]):
                        if drone.current_height == active_height:
                            collision_detected = True
                            drone.current_height += 10
                            output_area.insert(
                                "end",
                                f"Collision detected! Adjusting height of {drone.id} to {drone.current_height} meters.\n"
                            )
                            output_area.see("end")
        CentralHub.active_flights.append((drone, drone.path, drone.current_height))
        return collision_detected


class Order:
    def __init__(self, source, destination):
        self.source = source
        self.destination = destination

    @staticmethod
    def process_order(graph, source, destination, output_area):
        order = Order(source, destination)
        assigned_drone = CentralHub.assign_drone(order, graph, output_area)
        if assigned_drone:
            assigned_drone.assign_mission(source, destination, graph, output_area)


class DroneApp:
    def __init__(self, root):
        self.root = root
        self.graph = self.initialize_graph()
        self.orders = []
        self.unavailable_paths = []
        self.num_orders = 0
        self.output_area = scrolledtext.ScrolledText(self.root, wrap="word", height=20, width=80)
        self.setup_ui()

    def initialize_graph(self):
        graph = Graph()
        for i in range(1, 11):
            graph.add_node(i)
        graph.add_edge(1, 6, 5)
        graph.add_edge(1, 2, 3)
        graph.add_edge(6, 7, 8)
        graph.add_edge(7, 8, 5)
        graph.add_edge(8, 9, 4)
        graph.add_edge(9, 10, 2)
        graph.add_edge(7, 3, 3)
        graph.add_edge(3, 2, 2)
        graph.add_edge(2, 4, 5)
        graph.add_edge(4, 9, 5)
        graph.add_edge(4, 8, 3)
        graph.add_edge(3, 8, 4)
        graph.add_edge(5, 4, 4)
        graph.add_edge(5, 9, 4)
        graph.add_edge(5, 3, 3)
        return graph

    def setup_ui(self):
        self.root.title("Drone Management System")
        tk.Label(self.root, text="Number of Orders").grid(row=0, column=0)
        self.num_orders_entry = tk.Entry(self.root)
        self.num_orders_entry.grid(row=0, column=1)
        tk.Button(self.root, text="Submit", command=self.set_num_orders).grid(row=0, column=2)

        tk.Label(self.root, text="Source Node").grid(row=1, column=0)
        self.source_entry = tk.Entry(self.root)
        self.source_entry.grid(row=1, column=1)

        tk.Label(self.root, text="Destination Node").grid(row=2, column=0)
        self.destination_entry = tk.Entry(self.root)
        self.destination_entry.grid(row=2, column=1)

        tk.Label(self.root, text="Unavailable Paths (e.g., 1-2,3-4)").grid(row=3, column=0)
        self.unavailable_paths_entry = tk.Entry(self.root)
        self.unavailable_paths_entry.grid(row=3, column=1)

        tk.Button(self.root, text="Add Order", command=self.add_order).grid(row=4, column=0, columnspan=2)
        tk.Button(self.root, text="Process Orders", command=self.process_orders).grid(row=5, column=0, columnspan=2)

        self.output_area.grid(row=6, column=0, columnspan=3)
        tk.Button(self.root, text="Display Graph", command=lambda: self.graph.display_graph(self.output_area)).grid(
            row=7, column=0, columnspan=3)

    def set_num_orders(self):
        try:
            self.num_orders = int(self.num_orders_entry.get())
            self.orders = []
            self.output_area.insert("end", f"Ready to take {self.num_orders} orders.\n")
        except ValueError:
            self.output_area.insert("end", "Invalid number of orders.\n")

    def add_order(self):
        try:
            if len(self.orders) >= self.num_orders:
                self.output_area.insert("end", "All orders are already added.\n")
                return
            source = int(self.source_entry.get())
            destination = int(self.destination_entry.get())
            if source not in self.graph.nodes or destination not in self.graph.nodes:
                raise ValueError("Invalid node IDs.")

            unavailable_paths = self.unavailable_paths_entry.get().split(",")
            for path in unavailable_paths:
                if "-" in path:
                    src, dest = map(int, path.split("-"))
                    self.graph.add_unavailable_path(src, dest)

            self.orders.append((self.graph.nodes[source], self.graph.nodes[destination]))
            self.output_area.insert("end", f"Order added: Source {source} -> Destination {destination}\n")
        except ValueError as e:
            self.output_area.insert("end", f"Error: {e}\n")

    def process_orders(self):
        if len(self.orders) < self.num_orders:
            self.output_area.insert("end", "Please add all orders before processing.\n")
            return
        self.output_area.insert("end", "Processing all orders...\n")
        for source, destination in self.orders:
            Order.process_order(self.graph, source, destination, self.output_area)
        self.output_area.insert("end", "All orders processed successfully.\n")
        self.output_area.see("end")


if __name__ == "__main__":
    root = tk.Tk()
    app = DroneApp(root)
    root.mainloop()
